import * as React from 'react';
import AppBar from '@mui/material/AppBar';
import Box from '@mui/material/Box';
import Toolbar from '@mui/material/Toolbar';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import { Link } from 'react-router-dom';

const Appbar = () => {
    return (
        <Box sx={{ flexGrow: 1 }} style={{ marginBottom: "4PX", backgroundColor: "teal" }}>
            <AppBar position="static" color="transparent">
                <Toolbar>
                    <Typography component="div" sx={{ fontFamily: "sanserif", flexGrow: 1, textTransform: "uppercase", color: "white", fontSize: "20px" }}>
                        <Link to={"/"} style={{textDecoration:"none",color:"white"}}>
                            Shree Radhe Rani Enterprise
                        </Link>
                    </Typography>
                    <div style={{ gap: "10px", display: "flex" }}>
                        {/* <div>
                            <Button color="secondary" variant="outlined" style={{ border: "1px solid white" }}>
                                <Link to={"/blog "} style={{ textDecoration: "none", color: "white" }}>
                                    Blog
                                </Link >
                            </Button>
                        </div> */}
                        <div>
                            <Button color="secondary" variant="outlined" style={{ border: "1px solid white" }}>
                                <Link to={"/aboutus "} style={{ textDecoration: "none", color: "white" }}>
                                    About Us
                                </Link >
                            </Button>
                        </div>
                        <div>
                            <Button variant="outlined" style={{ border: "1px solid white" }}>
                                <Link to={"/getintouch "} style={{ textDecoration: "none", color: "white", border: "black" }}>
                                    Get In Touch
                                </Link >
                            </Button>
                        </div>
                    </div>
                </Toolbar>
            </AppBar>
        </Box>
    )
}

export default Appbar