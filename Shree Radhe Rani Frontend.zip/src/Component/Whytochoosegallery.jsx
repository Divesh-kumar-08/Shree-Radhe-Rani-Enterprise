import { Card, CardContent, Typography } from '@mui/material'
import React from 'react'

const Whytochoosegallery = () => {
  return (
    <div style={{ display: "flex", justifyContent: "space-evenly", gap: "25px", padding: "20px", textAlign: "center" }}>
    <Card style={{flex: "1"}}>
        <CardContent>
            <Typography gutterBottom variant="h5" component="div" style={{color:"teal"}}>
                5 Years Warranty
            </Typography>
            <Typography variant="body2" color="text.secondary">
              Shree Radhe Rani Enterprise offers interior designing as well as quailty products with a warranty of upto 5 years.
              </Typography>
        </CardContent>
    </Card>
    <Card style={{flex: "1"}}>

        <CardContent>
            <Typography gutterBottom variant="h5" component="div" style={{color:"teal"}}>
                Expert Designers
            </Typography>
            <Typography variant="body2" color="text.secondary">
            Shree Radhe Rani Enterprise offers interior designing as well as expert designers .
            </Typography>
        </CardContent>
    </Card>
    <Card style={{flex: "1"}}>

        <CardContent>
            <Typography gutterBottom variant="h5" component="div" style={{color:"teal"}}>
                Free Delivery
            </Typography>
            <Typography variant="body2" color="text.secondary">
            Shree Radhe Rani Enterprise offers onsite shopping as well as free delivery for the selected products
            </Typography>
        </CardContent>
    </Card>
</div>
  )
}

export default Whytochoosegallery