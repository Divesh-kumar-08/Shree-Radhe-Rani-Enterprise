import Carousel from 'react-bootstrap/Carousel';
import Ban1 from '../Images/banner1.jpg'
import Ban2 from '../Images/banner2.jpg'
import Ban3 from '../Images/banner3.jpg'

function Banner() {
  return (
    <Carousel style={{ padding: "20px",}}>
      <Carousel.Item>
        <img
          className="d-block w-100"
          src={Ban1}
          alt="First slide"
          width={"100%"}

        />
        <Carousel.Caption>
          <h3 style={{textShadow:"1px black"}}>Affordable Solutions For Better Living.</h3>
        </Carousel.Caption>
      </Carousel.Item>

      <Carousel.Item>
        <img
          className="d-block w-100"
          src={Ban2}
          alt="Second slide"
          width={"100%"}
        />

        <Carousel.Caption>
          <h3>We Bring Ideas To Life.</h3>
        </Carousel.Caption>
      </Carousel.Item>
      
      <Carousel.Item>
        <img
          className="d-block w-100"
          src={Ban3}
          alt="Third slide"
          width={"100%"}
        />

        <Carousel.Caption>
          <h3>Bringing Style And Comfort.</h3>
        </Carousel.Caption>
      </Carousel.Item>
    </Carousel>
  );
}

export default Banner;