import React, { useRef, useState } from 'react';
import emailjs from '@emailjs/browser';
import { Typography } from '@mui/material';
import axios from 'axios';

const Form = () => {
  const form = useRef();
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: "",
  })

  axios.defaults.baseURL = "http://localhost:5000/"

  const sendEmail = async (e) => {
    e.preventDefault();
    try {
      let res = await axios.post("api/v1/customer", {
        ...formData
      })
      if (res.status === 201) {
        setFormData({
          name : "",
          email : "",
          message : ""
        })
        alert("Message saved in Database")
      }
    } catch (error) {
      console.log(error)
    }

    emailjs.sendForm(
      'service_bcqghii',
      'template_koz8zcs',
      form.current, 'aDA1nH1T9bs8_T5wy')
      .then((result) => {
        console.log(result.text);
        console.log("message sent")
      }, (error) => {
        console.log(error.text);
      });
  }

  return (
    <div style={{ margin: "20px" }}>
      <Typography variant='h3'>Contact Us</Typography>
      <Typography variant='body2' style={{ textAlign: "center" }}>Schedule Free Consultation</Typography>
      <form ref={form} onSubmit={sendEmail} method='POST'>
        <div>
          <div style={{ margin: "10px" }}>
            <input value={formData.name} onChange={(e) => setFormData({
              ...formData,
              name: e.target.value
            })} type="text" name="name" placeholder="Name" style={{ width: "100%", border: "1px solid white", borderRadius: "4px" }} />
          </div>
          <div style={{ margin: "10px" }}>
            <input value={formData.email} onChange={(e) => setFormData({
              ...formData,
              email: e.target.value
            })} type="email" name="email" placeholder="Email" style={{ width: "100%", border: "1px solid white", borderRadius: "4px" }} />
          </div>
          <div style={{ margin: "10px" }}>
            <textarea value={formData.message} onChange={(e) => setFormData({
              ...formData,
              message: e.target.value
            })} name="message" placeholder="Message" style={{ width: "100%", border: "1px solid white", borderRadius: "4px" }} />
          </div>
          <div style={{ display: "flex", justifyContent: "center" }}>
            <input type="submit" value="Send" style={{ width: "80%", border: "none", background: "skyblue" }} />
          </div>
        </div>
      </form>
    </div>
  )
}

export default Form