import { Typography } from '@mui/material'
import React from 'react'
import { Button } from 'react-bootstrap'
import { Link } from 'react-router-dom'

const Footer = () => {
    return (
        <div style={{ backgroundColor: "white" }}>
            <div style={{ width: "100%", display: "flex", justifyContent: "space-around", verticalAlign: "middle", }}>
                <div style={{ margin: "10px", padding: "10px", color: "grey" }}>
                    <Typography variant='h6' style={{ color: "black" }}>Locate Us</Typography>
                    <Typography variant='body2'>Shree Radhe Rani Enterprise</Typography>
                    <Typography variant='body2'>MES Road, Jawahar Nagar, Adampur, Punjab 144102</Typography>
                </div>
                <div style={{ margin: "10px", padding: "10px", color: "grey" }}>
                    <Typography variant='h6' style={{ color: "black" }}>Reach Us At</Typography>
                    <Typography variant='body2'>Mobile No. +91 981 581 9185</Typography>
                    <Typography variant='body2'>Email. Shreeradheranil@gmail.com</Typography>
                </div>

                <div style={{ margin: "10px", padding: "10px" }}>
                    <Link to={"/termscondition "} style={{ textDecoration: "none", color: "grey", alignItems: "center" }}>
                        Terms & Conditions
                    </Link >
                </div>
            </div>
            <div style={{ color: "black", width:"100%", textAlign:"center" }}>
                Created By :Divesh kumar
            </div>
        </div>
    )
}

export default Footer