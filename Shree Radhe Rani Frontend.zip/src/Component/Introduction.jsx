import * as React from 'react';
import { styled } from '@mui/material/styles';
import Box from '@mui/material/Box';
import Paper from '@mui/material/Paper';
import Grid from '@mui/material/Grid';
import { Typography } from '@mui/material';


const Introduction = () => {
    const Item = styled(Paper)(({ theme }) => ({
        backgroundColor: theme.palette.mode === 'dark' ? '#1A2027' : '#fff',
        ...theme.typography.body2,
        padding: theme.spacing(1),
        textAlign: 'center',
        color: theme.palette.text.secondary,
    }));

    return (
        <Box sx={{ flexGrow: 1,width:"80%", margin:"auto", marginTop:"20px" }}>
            <Grid container >
                    <Item><Typography
                        padding="0"
                        margin="0"
                        fontSize="13px"
                        lineHeight="20px"
                        textTransform={"uppercase"}
                        marginbottom="5px"
                    >
                        shree radhe rani enterprise
                    </Typography>
                        <Typography variant="h5" component="div">Bringing Style And Comfort For Customer Satisfaction.</Typography>
                        <Typography variant="body2" color="text.secondary">
                            When you give your home the Livspace touch, you get both beauty and functionality. We employ state-of-the-art technology to ensure your home features a flawless look that lasts a very long time.
                        </Typography>
                    </Item>
                </Grid>
        </Box>
    );
}

export default Introduction