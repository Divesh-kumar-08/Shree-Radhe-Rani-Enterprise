import React from 'react'
import { Card, CardContent, CardMedia, Typography } from '@mui/material'

const Whatweoffergallery = ({heading, Content,img}) => {
    return (
        <div style={{ 
            // justifyContent: "space-evenly",
        margin:"10px"}}>
            <Card sx={{ maxWidth: 345, height:350 }}>
                <CardMedia
                    sx={{ height: 140 }}
                    image={img}
                    title="green iguana"
                />
                <CardContent >
                    <Typography gutterBottom variant="h5" component="div" style={{textAlign:"center",color:"teal"}} >
                        {heading}
                    </Typography>
                    <Typography variant="body2" color="text.secondary" textAlign="justify" >
                       {Content}
                    </Typography>
                </CardContent>
            </Card>

        </div>
    )
}

export default Whatweoffergallery