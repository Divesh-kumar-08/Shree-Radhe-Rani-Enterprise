import React from 'react'
import Whytochoosegallery from './Whytochoosegallery'

const Whytochoose = () => {
  return (
    <div>
        <div style={{textAlign:"center", marginTop:"20px", color:"black"}}><h2>Why To Choose</h2></div>
        
        <div style={{display:'flex', justifyContent:"space-evenly"}}> 
        <Whytochoosegallery/>
        </div>
        </div>
  )
}

export default Whytochoose