import React from 'react'
import Shree from '../Images/Shree.jpg'
import { Card, Typography } from '@mui/material'
// import Owner from './Owner'
const Aboutusintro = () => {
  return (
    <div style={{ boxShadow: "1px 2px 8px grey", display: "flex", gap: "10px" }}>
      <div style={{ padding: "10px" }}><img src={Shree} alt="" width="500px" /></div>
      <div style={{ padding: "10px" }}>
        <Card style={{ padding: "10px", textAlign:"justify"}}>
          <h2> Shree Radhe Rani </h2>
          <Typography variant="body2" style={{ color: "grey" }}> 
          Shree Radhe Rani Enterprise is a full-service interior design company located in the Punjab, India since 2019, specializing in both residential and commercial design. Whether you need a quick refresh of furniture and paint colors, or an extensive whole-house renovation, we can provide the expertise to make sure the project runs smoothly and gives you the best results possible.
          </Typography>
          <Typography variant="body2" style={{ color: "grey" }}> 
            Because we are a small design firm, we are extremely flexible and nimble. We have relationships with many local craftsmen and subcontractors, so you can be assured that your project is completed with the highest standards. Or, if you prefer, you can hire your own contractors, and we’ll work with them throughout the remodeling process.
          </Typography>
          <hr />
        </Card>
      </div>
    </div>
  )
}

export default Aboutusintro