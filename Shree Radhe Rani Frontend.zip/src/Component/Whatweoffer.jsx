import React from 'react'
import Whatweoffergallery from './Whatweoffergallery'
import '../App.css'
import Service1 from '../Images/service1.jpg'
import Service2 from '../Images/service2.jpg'
import Service3 from '../Images/service3.jpg'

const Whatweoffer = () => {
  return (
    <div>
      <div style={{ textAlign: "center", marginTop: "10px",color:"black" }}><h2>What We Offer</h2></div>
      <div className='Whatweoffer' 
      // style={{ display: 'flex', justifyContent: "space-evenly" }}
      >
        <Whatweoffergallery heading={"Interior Furniture"} Content={"Interior furniture includes all the living goods from cupboard to sofas and beds."} img={Service1}/>
        <Whatweoffergallery heading={"Commercial Furniture"} Content={"Commercial furniture focus on creating public spaces such as schools, office, retail stores furnishing."} img={Service2}/>
        <Whatweoffergallery heading={"Residential Furniture"} Content={"Residential furniture focus on furnishing at small scale such as private homes, condos, and apartments."} img={Service3}/> </div>

    </div>
  )
}

export default Whatweoffer