import React from 'react'
import Appbar from '../Component/Appbar'
import Banner from '../Component/Banner'
import Introduction from '../Component/Introduction'
import Whatweoffer from '../Component/Whatweoffer'
import Whytochoose from '../Component/Whytochoose'
import Footer from '../Component/Footer'

const Home = () => {
    return (
        <div style={{backgroundColor:"beige"}}>
            <Appbar />
            <Banner />
            <Introduction />
            <Whatweoffer />
            <Whytochoose />
            <Footer />
        </div>
    )
}

export default Home