import React from 'react'
import Appbar from '../Component/Appbar'
import Footer from '../Component/Footer'

const Blog = () => {
  return (
    <div>
        <Appbar/>
        
        <Footer/>
    </div>
  )
}

export default Blog