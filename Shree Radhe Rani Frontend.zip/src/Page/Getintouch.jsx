import React from 'react'
import Appbar from '../Component/Appbar'
import { Box} from '@mui/material'
import Footer from '../Component/Footer'
import Form from '../Component/Form'
const Getintouch = () => {
    return (
        <div >
            <Appbar />

            <div style={{ position: 'relative' }}>
                <div>
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3404.5094963835027!2d75.72261721514832!3d31.42763768140054!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x391af955e81afaa7%3A0x8fe031900fd1e253!2sShri%20Radhe%20Rani%20Enterprises!5e0!3m2!1sen!2sin!4v1684498594101!5m2!1sen!2sin"
                        width={"100%"}
                        height={"450"}
                        style={{ border: "0" }}
                        loading={"lazy"} >
                    </iframe>
                </div>
                <div style={{
                }}>
                    <Box style={{
                        height: "400px",
                        display: "flex",
                        flexDirection: "column",
                        position: "absolute",
                        alignItems: "flex-end",
                        width: "400px",
                        rowGap: "10px",
                        bottom: "10px",
                        right: "10px",
                        background: "rgba(169, 169, 169, 0.8)" ,
                       borderRadius:"16px",
                        // border: "1px solid rgba(130, 152, 171, 0.2)",
                        margin: "auto",
                        alignItems: "center",
                        padding: "10px",

                    }}>
                        <Form />
                    </Box>
                </div>
            </div >
            <Footer />
        </div>
    )
}

export default Getintouch