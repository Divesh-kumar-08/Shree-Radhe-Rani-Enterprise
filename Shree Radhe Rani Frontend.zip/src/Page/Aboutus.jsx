import React from 'react'
import Appbar from '../Component/Appbar'
import Aboutusintro from '../Component/Aboutusintro'
import Footer from '../Component/Footer'

const Aboutus = () => {
  return (
    <div style={{ backgroundColor:"#f8f9fa"}}>
        <Appbar/>
        <Aboutusintro/>
        <Footer/>
    </div>
  )
}

export default Aboutus