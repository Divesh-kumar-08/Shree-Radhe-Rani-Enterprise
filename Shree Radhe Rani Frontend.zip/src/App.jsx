import React from 'react'
import Home from './Page/Home'
import Getintouch from './Page/Getintouch'
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import Aboutus from './Page/Aboutus'
import Termandcondition from '../src/Component/Termandconditions'
import Products from './Page/Blog'
import Blog from './Page/Blog'

const App = () => {
  return (
    <div>
      <BrowserRouter>
        <Routes>
          <Route path='/' element={<Home /> }></Route>
          <Route path='/aboutus' element={<Aboutus/>}></Route>
          <Route path='/blog' element={<Blog/>}></Route>
          <Route path='/getintouch' element={<Getintouch/>}></Route>
          <Route path='/termscondition' element={<Termandcondition /> }></Route>
        </Routes>
        
      </BrowserRouter>
      
    </div>
  )
}

export default App