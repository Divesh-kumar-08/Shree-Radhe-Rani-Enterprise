import express from 'express'
import mongoose from 'mongoose'
import cors from 'cors'

const CustomerSchema = mongoose.Schema({
    name: {
        type: String,
        required: true,
        trim: true
    },
    email: {
        type: String,
        required: true,
        trim: true
    },
    message: {
        type: String,
        required: true,
        trim: true
    }
}, {
    timestamps: true
})

const Customer = mongoose.model("Customer", CustomerSchema)

const app = express()


app.use(express.json({ extended: true }))
app.use(cors())


app.get("/", (req, res) => {
    res.send("Hello")
})

let connectionString = "mongodb+srv://divesh:divesh@cluster0.krbti1n.mongodb.net/?retryWrites=true&w=majority"

mongoose.connect(connectionString).then(() => {
    console.log("Connected to Mongo DB")
}).catch(err => console.log(err))

// post 
// http://localhost:5000/api/v1/customer

app.post("/api/v1/customer", async (req, res) => {
    try {
        const data = req.body;
        if(!data.name || !data.email || !data.message){
            return res.status(400).json({message : "All Fields are required"})
        }
        const newCustomer = await new Customer(data).save()
        res.status(201).json(newCustomer)
    } catch (error) {
        res.status(500).json({ error: error.message })
    }
})

app.listen(5000, () => {
    console.log("Server is listening on PORT : 5000")
})